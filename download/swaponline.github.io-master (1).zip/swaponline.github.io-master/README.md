# swaponline.github.io

How to build own crypto wallet on my own site?

1. click "Clone or download" on https://github.com/swaponline/swaponline.github.io/
2. unzip to your site using FTP

How to add ERC20 ?
1. https://github.com/swaponline/swap.react/


# FAQ

Q: I have installed the wallet testing . Now I was able to creat a wallet and got a private key without importing my own private key . That is my question , which node is that wallet connected to ? Yours ?
A: Bitpay for Bitocin, Infura for Ethereum
